window.onload = function() {
    var heading2 = document.getElementById("heading2");
    var h2 = document.createElement("h2");
    h2.textContent = "Country List";
    heading2.appendChild(h2);
  
    var tableDiv = document.getElementById("table");
    var table = document.createElement("table");
    // table.style.border = "0.5px solid black";
   //table.style.width = "100%"; // Set table width to 100%


    var thead = document.createElement("thead");
    var tr = document.createElement("tr");
    var th1 = document.createElement("th");
    th1.textContent = "Country";
    var th2 = document.createElement("th");
    th2.textContent = "Capital";
    //th2.style.width = "5cm"; // Set a specific width for the "Capital" column


    tr.appendChild(th1);
    tr.appendChild(th2);
    thead.appendChild(tr);
    table.appendChild(thead);
  
    var tbody = document.createElement("tbody");
  
    for (var i = 0; i < countries.length; i++) {
      var tr = document.createElement("tr");
      
    // Loop for "Country"
    var td1 = document.createElement("td");
    td1.textContent = countries[i].Name;
    tr.appendChild(td1);
    
    // Loop for "Capital"
    var td2 = document.createElement("td");
   // td2.style.width = "5cm";
    td2.textContent = countries[i].Capital;
    //td2.style.width = "5cm";
    tr.appendChild(td2);
    //td2.style.width = "5cm";

      tbody.appendChild(tr);
    }
  
    table.appendChild(tbody);
    tableDiv.appendChild(table);
  
    var flagImagesLink = document.getElementById("flag-images");
    var flagsDiv = document.getElementById("flags");
  
    flagImagesLink.addEventListener("click", function() {
      for (var j = 0; j < countries.length; j++) {
        var img1 = document.createElement("img");
        var str = "./flags/" + countries[j].Name + "-flag.png";
        img1.setAttribute("src", str);
        img1.setAttribute("alt", "Flag of " + countries[j].Name);
        img1.setAttribute("width", "200");
        img1.setAttribute("height", "200");
        flagsDiv.appendChild(img1);
      }
      flagImagesLink.parentNode.removeChild(flagImagesLink);
    });
  };
  